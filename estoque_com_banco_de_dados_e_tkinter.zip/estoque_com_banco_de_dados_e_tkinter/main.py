# Autor: Gustavo Rossi Babberg Lima
# Protótipo de projeto de controle de estoque

import sqlite3
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
from datetime import datetime


DB_NAME = 'estoque.db'
CONN = None
CURSOR = None


def conectar_db():
    global CONN, CURSOR
    try:
        CONN = sqlite3.connect(DB_NAME)
        CURSOR = CONN.cursor()
        CURSOR.execute("""
            CREATE TABLE IF NOT EXISTS produtos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome_produto TEXT NOT NULL,
                quantidade INTEGER,
                descricao TEXT,
                quantidade_minima INTEGER
            )
        """)
        CURSOR.execute("""
            CREATE TABLE IF NOT EXISTS historico (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                produto_id INTEGER,
                operacao TEXT NOT NULL,
                detalhes TEXT,
                responsavel TEXT,
                data_hora TEXT
            )
        """)
        CONN.commit()
        return True
    except sqlite3.Error as e:
        messagebox.showerror("Erro de DB", f"Não foi possível conectar ao banco de dados: {e}")
        return False


def registrar_historico(produto_id, operacao, detalhes, app_instance):
    responsavel = simpledialog.askstring("Responsável", "Nome do responsável pela operação:", parent=app_instance)
    if not responsavel:
        responsavel = "N/A"

    data_hora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    sql = "INSERT INTO historico (produto_id, operacao, detalhes, responsavel, data_hora) VALUES (?, ?, ?, ?, ?)"
    try:
        CURSOR.execute(sql, (produto_id, operacao, detalhes, responsavel, data_hora))
        CONN.commit()
    except Exception as e:
        messagebox.showerror("Erro", f"Erro ao registrar histórico: {e}")


class EstoqueApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Gerenciamento de Estoque 📦")
        self.geometry("850x650")

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(pady=10, padx=10, expand=True, fill="both")

        self.frame_inventario = ttk.Frame(self.notebook)
        self.frame_cadastro = ttk.Frame(self.notebook)
        self.frame_historico = ttk.Frame(self.notebook)

        self.notebook.add(self.frame_inventario, text="Inventário Atual")
        self.notebook.add(self.frame_cadastro, text="Cadastro/Edição")
        self.notebook.add(self.frame_historico, text="Histórico")
        
        self.setup_inventario_tab()
        self.setup_cadastro_tab()
        self.setup_historico_tab()

        self.update_inventario_treeview()
    
    def setup_inventario_tab(self):

        self.tree = ttk.Treeview(self.frame_inventario, columns=("ID", "Produto", "Qtd", "Qtd Mínima", "Descrição"), show="headings")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Produto", text="Produto")
        self.tree.heading("Qtd", text="Qtd")
        self.tree.heading("Qtd Mínima", text="Qtd Mínima")
        self.tree.heading("Descrição", text="Descrição")
        
        self.tree.column("ID", width=40, anchor="center")
        self.tree.column("Produto", width=150)
        self.tree.column("Qtd", width=60, anchor="center")
        self.tree.column("Qtd Mínima", width=90, anchor="center")
        self.tree.column("Descrição", width=300)

        vsb = ttk.Scrollbar(self.frame_inventario, orient="vertical", command=self.tree.yview)
        vsb.pack(side='right', fill='y')
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(fill="both", expand=True, padx=5, pady=5)
        
        self.tree.bind("<Double-1>", self.on_double_click_tree)
        
        ttk.Label(self.frame_inventario, text="ALERTA DE ESTOQUE MÍNIMO", font=("Arial", 10, "bold")).pack(pady=(10, 0))
        # Ajustei a cor para ficar mais suave
        self.alert_text = tk.Text(self.frame_inventario, height=4, state='disabled', wrap='word', bg='#fff0f0') 
        self.alert_text.pack(fill="x", padx=5, pady=(0, 10))
        
        button_frame = ttk.Frame(self.frame_inventario)
        button_frame.pack(fill="x", pady=5)
        ttk.Button(button_frame, text="Atualizar Inventário", command=self.update_inventario_treeview).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Excluir Produto Selecionado", command=self.excluir_produto_gui).pack(side="right", padx=5)
        ttk.Button(button_frame, text="Editar Produto Selecionado", command=lambda: self.notebook.select(self.frame_cadastro)).pack(side="right", padx=5)


    def update_inventario_treeview(self):
        for i in self.tree.get_children():
            self.tree.delete(i)

        CURSOR.execute("SELECT id, nome_produto, quantidade, quantidade_minima, descricao FROM produtos ORDER BY id DESC")
        produtos = CURSOR.fetchall()
        
        alertas = []

        for p in produtos:
            self.tree.insert("", "end", values=p)
    
            if p[2] < p[3]: 
                alertas.append(f"'{p[1]}' ({p[0]}) está com {p[2]} unidades (Mínimo: {p[3]})\n")
        
        self.alert_text.config(state='normal')
        self.alert_text.delete(1.0, tk.END)
        if alertas:
            self.alert_text.insert(tk.END, "".join(alertas))
            self.alert_text.tag_configure("alert", foreground="red")
        else:
            self.alert_text.insert(tk.END, "Nenhum alerta de estoque mínimo no momento.")
        self.alert_text.config(state='disabled')
        
        if self.notebook.tab(self.notebook.select(), "text") != "Inventário Atual":
              self.notebook.select(self.frame_inventario)

    def on_double_click_tree(self, event):
        item = self.tree.selection()
        if item:
            produto_id = self.tree.item(item, "values")[0]
            self.carregar_produto_para_edicao(produto_id)
            self.notebook.select(self.frame_cadastro)
    
    def excluir_produto_gui(self):
        item = self.tree.selection()
        if not item:
            messagebox.showwarning("Aviso", "Selecione um produto para excluir.")
            return
            
        produto_id = self.tree.item(item, "values")[0]
        nome_produto = self.tree.item(item, "values")[1]
        
        if messagebox.askyesno("Confirmação", f"Tem certeza que deseja EXCLUIR '{nome_produto}' (ID: {produto_id})?"):
            try:
                CURSOR.execute("DELETE FROM produtos WHERE id = ?", (produto_id,))
                CONN.commit()
                registrar_historico(produto_id, "EXCLUSÃO", f"Produto '{nome_produto}' removido do sistema.", self) 
                messagebox.showinfo("Sucesso", f"Produto ID {produto_id} excluído com sucesso!")
                self.update_inventario_treeview()
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao excluir: {e}")


    def setup_cadastro_tab(self):
        self.produto_id_var = tk.StringVar(value="")
        self.nome_var = tk.StringVar()
        self.qtd_var = tk.StringVar(value="0")
        self.qtd_min_var = tk.StringVar(value="0")
        self.descricao_var = tk.StringVar()
        
        self.cadastro_title = ttk.Label(self.frame_cadastro, text="CADASTRAR NOVO PRODUTO", font=("Arial", 14, "bold"))
        self.cadastro_title.pack(pady=10)
        
        ttk.Label(self.frame_cadastro, text="ID do Produto (somente leitura):").pack(pady=(5, 0))
        ttk.Entry(self.frame_cadastro, textvariable=self.produto_id_var, state='readonly').pack(padx=20, fill="x")


        fields = [
            ("Nome do Produto:", self.nome_var),
            ("Quantidade em Estoque:", self.qtd_var),
            ("Quantidade Mínima:", self.qtd_min_var),
        ]
        
        for label_text, var in fields:
            ttk.Label(self.frame_cadastro, text=label_text).pack(pady=(5, 0))
            ttk.Entry(self.frame_cadastro, textvariable=var).pack(padx=20, fill="x")


        ttk.Label(self.frame_cadastro, text="Descrição:").pack(pady=(5, 0))
        self.descricao_entry = tk.Text(self.frame_cadastro, height=5)
        self.descricao_entry.pack(padx=20, fill="x")


        button_frame = ttk.Frame(self.frame_cadastro)
        button_frame.pack(pady=20)
        ttk.Button(button_frame, text="Salvar Produto", command=self.salvar_produto).pack(side="left", padx=10)
        ttk.Button(button_frame, text="Limpar Formulário", command=self.limpar_formulario).pack(side="left", padx=10)


    def limpar_formulario(self):
        self.produto_id_var.set("")
        self.nome_var.set("")
        self.qtd_var.set("0")
        self.qtd_min_var.set("0")
        self.descricao_entry.delete(1.0, tk.END)
        self.cadastro_title.config(text="CADASTRAR NOVO PRODUTO")


    def carregar_produto_para_edicao(self, produto_id):
        self.limpar_formulario()
        try:
            CURSOR.execute("SELECT id, nome_produto, quantidade, descricao, quantidade_minima FROM produtos WHERE id = ?", (produto_id,))
            produto = CURSOR.fetchone()
            
            if produto:
                self.produto_id_var.set(produto[0])
                self.nome_var.set(produto[1])
                self.qtd_var.set(produto[2])
                self.descricao_entry.delete(1.0, tk.END)
                self.descricao_entry.insert(tk.END, produto[3])
                self.qtd_min_var.set(produto[4])
                self.cadastro_title.config(text=f"EDITAR PRODUTO ID: {produto[0]}")
            else:
                messagebox.showerror("Erro", f"Produto com ID {produto_id} não encontrado.")
                self.limpar_formulario()
        except Exception as e:
            messagebox.showerror("Erro de DB", f"Erro ao carregar produto: {e}")


    def salvar_produto(self):
        nome_produto = self.nome_var.get().strip()
        descricao = self.descricao_entry.get(1.0, tk.END).strip()
        produto_id = self.produto_id_var.get()
        
        if not nome_produto:
            messagebox.showerror("Erro", "O nome do produto não pode estar vazio.")
            return

        try:
            qtd = int(self.qtd_var.get())
            qtd_min = int(self.qtd_min_var.get())
        except ValueError:
            messagebox.showerror("Erro", "Quantidade e Qtd Mínima devem ser números inteiros.")
            return
        
        if produto_id:
            try:
                CURSOR.execute("SELECT quantidade, quantidade_minima, nome_produto FROM produtos WHERE id = ?", (produto_id,))
                prod_antigo = CURSOR.fetchone()
                
                sql = """
                    UPDATE produtos
                    SET nome_produto = ?, quantidade = ?, descricao = ?, quantidade_minima = ?
                    WHERE id = ?
                """
                CURSOR.execute(sql, (nome_produto, qtd, descricao, qtd_min, produto_id))
                CONN.commit()

                detalhes = f"Qtd de {prod_antigo[0]} para {qtd}. Mínimo de {prod_antigo[1]} para {qtd_min}."
                # Passa a instância para a função de histórico
                registrar_historico(produto_id, "EDIÇÃO", detalhes, self) 

                messagebox.showinfo("Sucesso", f"Produto ID {produto_id} atualizado com sucesso!")
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao editar no banco: {e}")
        
        else:
            try:
                sql = "INSERT INTO produtos (nome_produto, quantidade, descricao, quantidade_minima) VALUES (?, ?, ?, ?)"
                CURSOR.execute(sql, (nome_produto, qtd, descricao, qtd_min))
                produto_id = CURSOR.lastrowid
                CONN.commit()
                
                # Passa a instância para a função de histórico
                registrar_historico(produto_id, "INSERÇÃO", f"Qtd inicial: {qtd}", self) 
                
                messagebox.showinfo("Sucesso", f"Produto '{nome_produto}' inserido com sucesso!")
                self.limpar_formulario()
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao inserir no banco: {e}")
                
        self.update_inventario_treeview()


    def setup_historico_tab(self):
        self.history_tree = ttk.Treeview(self.frame_historico, columns=("Data", "Responsável", "Operação", "Prod ID", "Detalhes"), show="headings")
        self.history_tree.heading("Data", text="Data/Hora")
        self.history_tree.heading("Responsável", text="Responsável")
        self.history_tree.heading("Operação", text="Operação")
        self.history_tree.heading("Prod ID", text="Prod ID")
        self.history_tree.heading("Detalhes", text="Detalhes")
        
        self.history_tree.column("Data", width=150)
        self.history_tree.column("Responsável", width=120)
        self.history_tree.column("Operação", width=90, anchor="center")
        self.history_tree.column("Prod ID", width=70, anchor="center")
        self.history_tree.column("Detalhes", width=350)


        vsb = ttk.Scrollbar(self.frame_historico, orient="vertical", command=self.history_tree.yview)
        vsb.pack(side='right', fill='y')
        self.history_tree.configure(yscrollcommand=vsb.set)
        self.history_tree.pack(fill="both", expand=True, padx=5, pady=5)
        
        ttk.Button(self.frame_historico, text="Atualizar Histórico", command=self.update_historico_treeview).pack(pady=10)
        
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_change)


    def on_tab_change(self, event):
        selected_tab = self.notebook.tab(self.notebook.select(), "text")
        if selected_tab == "Histórico":
            self.update_historico_treeview()
            
    def update_historico_treeview(self):
        for i in self.history_tree.get_children():
            self.history_tree.delete(i)

        CURSOR.execute("SELECT data_hora, responsavel, operacao, produto_id, detalhes FROM historico ORDER BY data_hora DESC")
        historico = CURSOR.fetchall()

        if historico:
            for h in historico:
                self.history_tree.insert("", "end", values=h)
        else:
            self.history_tree.insert("", "end", values=("", "Nenhuma movimentação registrada.", "", "", ""))


    def on_closing(self):
        if messagebox.askokcancel("Sair", "Deseja realmente sair da aplicação?"):
            if CONN:
                CONN.close()
            self.destroy()


if __name__ == "__main__":
    if conectar_db():
        app = EstoqueApp()
        app.protocol("WM_DELETE_WINDOW", app.on_closing)
        app.mainloop()